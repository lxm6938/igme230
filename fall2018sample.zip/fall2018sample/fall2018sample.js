/* Don't use <script> tags in a linked js file! */


var menu = document.getElementsByClassName('menuitem');

$(menu).click(function () {
    $(submenu).slideToggle("slow");
});

function showMenu() {
    var submenu = document.getElementsByClassName('submenu');

    for (let x of submenu) {
        if (x.style.display === "none") {
            x.style.display = "block";
        } else {
            x.style.display = "none";
        }
    }

}

menu.onclick = showMenu();


